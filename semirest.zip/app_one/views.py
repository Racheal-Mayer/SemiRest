from django.shortcuts import render, redirect
from .models import *

def index(request):
    context = {
        "show" : Show.objects.all()
    }
    return render(request, "index.html", context)

def addshow(request):
    Show.objects.create(title=request.POST['title'], desc= request.POST['desc'], date = request.POST['date'], network = request.POST['network'])
    return redirect("/")

def edit(request,show_id):
    context = {
        "show_id" : show_id
    }
    return render(request, "edit.html", context)

def process_edit(request, show_id):
    # use id to grab show
    show_to_edit = Show.objects.get(id=show_id)
    # edit the value field with post date
    show_to_edit.title = request.POST['title_edit']
    show_to_edit.date = request.POST['date_edit']
    show_to_edit.network = request.POST['network_edit']
    show_to_edit.desc = request.POST['desc_edit']
    # save the show
    show_to_edit.save()
    return redirect('/')

def delete(request, show_id):
    show_to_delete = Show.objects.get(id=show_id)
    show_to_delete.delete()
    return redirect('/')

def show (request, show_id):
    context = {
        "show" : Show.objects.get(id=show_id)
    }
    return render(request, "show.html", context)